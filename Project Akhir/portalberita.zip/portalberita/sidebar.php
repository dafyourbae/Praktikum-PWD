<?=beritaterbaru(); ?>

<div class="clear"></div>

<?=populer()?>