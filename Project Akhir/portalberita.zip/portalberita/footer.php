</div>

</div>

<footer>
	<div class="wrap">
		<div class="pd10">
			<div class="footer pd10">
				Copyright &copy; 2021 | <a href="tentangkita.php" class="footer">Tentang Kita</a>
			</div>
		</div>
	</div>
</footer>

</body>
</html>