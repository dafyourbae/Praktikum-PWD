<?php
    session_start();
    session_destroy();
?>
<script language script="javascript">
    alert('Anda Berhasil Logout');
    document.location='tugas_login.php';
</script>