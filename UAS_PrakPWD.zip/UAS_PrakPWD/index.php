<?php
    session_start();
    if(!isset($_SESSION["login"])) {
        header("Location: login.php");
        exit;
    }
	require "functions.php";
	$guestbook = query("SELECT * FROM guestbook");


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Halaman Admin</title>
</head>
<body>
    <h1>Daftar Guestbook</h1>
    <a href="logout.php">Log Out</a>
    <br>
    <form action="" method="POST">
    </form>
    <br>
    <div id="container">
    <table border="1" cellpadding="10" cellspacing="0">
        <tr>   
            <th>No</th>
            <th>Date</th>
            <th>Name</th>
            <th>Email</th>
            <th>Address</th>
            <th>Message</th>
            <th>Aksi</th>
        </tr>
        <?php $i = 1 ?>
        <?php foreach ($guestbook as $row) : ?>
        <tr>
            <td><?= $i ?></td>
            <td><?= $row["date"]; ?></td>
            <td><?= $row["name"]; ?></td>
            <td><?= $row["email"]; ?></td>
            <td><?= $row["address"]; ?></td>
            <td><?= $row["message"]; ?></td>
            <td><a href="edit.php?id=<?= $row["id"];?>">Edit</a> |
            <a href="hapus.php?id=<?= $row["id"];?>" onclick="return confirm('apakah anda ingin menghapus data?');">Hapus</a></td>
        </tr>
        <?php $i++ ?>
        <?php endforeach; ?>
    </table>
    </div>
    <script type="text/javascript" src="js/script.js"></script>
</body>
</html>