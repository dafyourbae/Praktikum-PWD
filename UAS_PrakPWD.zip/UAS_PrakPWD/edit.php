<?php require 'functions.php';

$id = $_GET["id"];
$qry = query("SELECT * FROM guestbook WHERE id =$id")[0];

if(isset($_POST["submit"])){
	if(edit($_POST) > 0){
		echo "
			<script>
				alert ('Data berhasil diedit');
				document.location.href = 'index.php';
			</script>
		";
	}else{
		echo "
			<script>
				alert ('Data gagal diedit');
				document.location.href = 'index.php';
			</script>
		";
	}
}
?>
<html>
<head>
	<title>Edit Data Guestbook</title>
</head>
<body>
	<h1>Edit Data Guestbook</h1>
	<form action="" method="POST" enctype="multipart/form-data">
		<input type='hidden' name='id' value="<?= $qry["id"];?>">
		<ul>
			<li>
				<label for="name">name :</label>
				<input type="text" name="name" id="name" required value="<?= $qry["name"];?>"/>
			</li>
			<li>
				<label for="email">Email :</label>
				<input type="text" name="email" id="email" required value="<?= $qry["email"];?>"/>
			</li>
			<li>
				<label for="address">address :</label>
				<input type="text" name="address" id="address" required value="<?= $qry["address"];?>"/>
			</li>
			<li>
				<label for="message">message :</label>
				<input type="text" name="message" id="message" required value="<?= $qry["message"];?>"/>
				
				
			</li>
			<li>
				<label for="date">date :</label>
				<input type="date" name="date" id="date" required value="<?= $mhs["date"];?>"/>
			</li>
			<li>
				<button type="submit" name="submit">Edit Data</button>
			</li>
		</ul>
	</form>
	
</body>
</html>