<?php
    session_start();
    if(!isset($_SESSION["login"])) {
        header("Location: login.php");
        exit;
    }
	require "functions.php";
	$guestbook = query("SELECT * FROM guestbook");


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Halaman Member</title>
</head>
<body>
    <h1>Silahkan klik link untuk tambah pesan anda</h1>
    <a href="tambah.php">Tambahkan</a>
    <h3>klik dibawah untuk logout</h3>
    <a href="logout.php">Log Out</a>
    <form action="" method="POST">
    </form>
    <br>
    <div id="container">
    <table border="1" cellpadding="10" cellspacing="0">
        <tr>   
            <th>No</th>
            <th>Date</th>
            <th>Name</th>
            <th>Email</th>
            <th>Address</th>
            <th>Message</th>
        </tr>
        <?php $i = 1 ?>
        <?php foreach ($guestbook as $row) : ?>
        <tr>
            <td><?= $i ?></td>
            <td><?= $row["date"]; ?></td>
            <td><?= $row["name"]; ?></td>
            <td><?= $row["email"]; ?></td>
            <td><?= $row["address"]; ?></td>
            <td><?= $row["message"]; ?></td>
        </tr>
        <?php $i++ ?>
        <?php endforeach; ?>
    </table>
    </div>
    <script type="text/javascript" src="js/script.js"></script>
</body>
</html>