<?php
    $conn = mysqli_connect("localhost", "root", "", "guest");

    function query($query) {
        global $conn;
        $result = mysqli_query($conn, $query);
        $rows = [];

        while ($row = mysqli_fetch_assoc($result)) {
            $rows[] = $row;
        }
        return $rows;
    }
    
    function registrasi($data){
        global $conn;

        $username = strtolower($data["username"]);
        $password = mysqli_real_escape_string($conn, $data["password"]);
        $password2 = mysqli_real_escape_string($conn, $data["password2"]);

        //Cek Username
        $result = mysqli_query($conn, "SELECT username FROM user WHERE username = '$username'");
        if (mysqli_fetch_assoc($result)){
            echo "<script>
                    alert('Username Sudah Terdaftar')
                    </script>";
            return false;
        }

        //Cek Konfirmasi Password
        if ($password !== $password2) {
            echo "<script>
                    alert('Konfirmasi Password Tidak Sesuai')
                </script>";
            return false;
        }

        //Tambahkan User Baru Ke DB
        mysqli_query($conn,"INSERT INTO user VALUES('','$username','$password')");
        return mysqli_affected_rows($conn);
    }


        //HAPUS
    function hapus($id){
        global $conn;
        mysqli_query($conn, "DELETE FROM guestbook WHERE id = $id");
        return mysqli_affected_rows($conn);
    }

    //EDIT
    function edit($data){
        global $conn;
        $id = $data["id"];
        $date = htmlspecialchars($data['date']);
        $name = htmlspecialchars($data['name']);
        $email = htmlspecialchars($data['email']);
        $address = htmlspecialchars($data['address']);
        $message = htmlspecialchars($data['message']);

        $query = "UPDATE guestbook SET 
                    date = '$date', name = '$name', email = '$email', address = '$address', message = '$message' WHERE id = '$id'
                ";
        mysqli_query($conn, $query);
        
        return mysqli_affected_rows($conn);
    }
    function tambah($data){
        global $conn;
        $date = htmlspecialchars($data['date']);
        $name = htmlspecialchars($data['name']);
        $email = htmlspecialchars($data['email']);
        $address = htmlspecialchars($data['address']);
        $message = htmlspecialchars($data['message']);
        $query = "insert INTO guestbook (id, date, name, email, address, message) 
        VALUES('','$date', '$name', '$email', '$address', '$message')";

        mysqli_query($conn, $query);

        return mysqli_affected_rows($conn);
    }
    
?>