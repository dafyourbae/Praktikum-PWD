<form method='post'>
    <center><h2>Login</h2>
        <p align='center'>
        username : <input type='text' name='username'><br>
        password : <input type='password' name='password'><br>
        <input type='submit' name='submit'></br>
        <a href="registrasi.php">Registrasi dahulu jika tidak ada akun</a>
        </p>
    </center>
</form>

<?php
    
    session_start();

    $conn = mysqli_connect('localhost', 'root', '', 'guest');


    if (isset($_POST["submit"])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        
        $sql = "SELECT * FROM user WHERE username = '$username' and password = '$password'";
        $query = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($query);
        if ($row['username'] != ""){
            //berhasil login
            $_SESSION['username'] = $row['username'];
            $_SESSION['login'] = true;
            if ($row['username']=='admin') {
                $_SESSION['username']='admin';
                ?>
                <script language script="JavaScript">
                alert('Anda Login Sebagai <?php echo $row['username']; ?>');
                document.location.href = 'index.php';
                </script>

                <?php
            }else {
                ?>
                <script language script="JavaScript">
                alert('Anda Login Sebagai <?php echo $row['username']; ?>');
                document.location= 'member.php';
                </script>
                <?php
            }
        }else{
            //gagal login
            ?>
            <script languange script = "Javascript">
                alert ("Gagal Login");
                document.location = 'login.php';
            </script>
            <?php
        }
    }
?>