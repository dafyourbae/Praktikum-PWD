<?php
require 'functions.php';
error_reporting(E_ALL&E_NOTICE);

//cek tombol submit sudah ditekan atau belom
if (isset($_POST["submit"])) {
    
    //cek jika berhasil ditambahkan
    if (tambah($_POST) > 0){
        
        echo 
            "<script>
				alert('Data berhasil ditambahkan');
				document.location.href = 'member.php';
			</script> ";
    }else{
        echo 
            "<script>
				alert('Data gagal untuk ditambahkan');
				document.location.href = 'member.php';
			</script>";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah data GuestBook</title>
</head>
<body>
    <h1>Tambah Data GuestBook</h1>

    <form action="" method="POST">
    <ul>
        <li>
            <label for="name">Name :</label>
            <input type="text" name="name" id="name" required/>
    
        </li>
        <li>
            <label for="email">Email :</label>
            <input type="text" name="email" id="email" required/>
        </li>
        <li>
            <label for="address">Address :</label>
            <input type="text" name="address" id="address" required/>
        </li>
        <li>
            <label for="message">Your message:</label>
            <textarea id="message" name="message"required></textarea>
        </li>

        <li>
            <label for="date">Date :</label>
            <input type="date" name="date" id="date" required/>
        </li>
        <li>
        <button type="submit" name="submit">Tambah Data</button>
        </li>
    </ul>
    </form>
</body>
</html>